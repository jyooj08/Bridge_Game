#include "irrKlang/irrKlang.h"

bool init_sound();
void set_sound(char* mp3_path);
void play_sound();
void stop_sound();
void finalize_sound();