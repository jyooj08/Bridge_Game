#include "cgmath.h"			// slee's simple math library
#include "cgut2.h"			// slee's OpenGL utility

bool init_model();
void finalize_model();
void render_model();