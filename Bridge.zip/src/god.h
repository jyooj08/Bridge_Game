#ifndef _GOD_H_
#define _GOD_H_
// Those who rule the laws of nature and physics, 'THE GOD'
// Implementation of phsycial objects

#include "animator.h"




#endif
